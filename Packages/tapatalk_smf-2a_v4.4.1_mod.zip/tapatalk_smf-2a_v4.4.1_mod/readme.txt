[center][color=red][size=18pt]Tapatalk for SMF Plugin[/size][/color][/center]
[center][size=8pt]For SMF 2.0 RC5/Final, http://tapatalk.com[/size][/center]

[b]What is Tapatalk?[/b]
Tapatalk is a forum app for iPhone/iPad, Android and Windows platform. The app provides super fast forum access to any vBulletin, IPBoard, phpBB, SMF, xenForo, MyBB and Kunena forums that have activated Tapatalk. Forum owner can download the free plug-in to activate Tapatalk in your forum.

[b]What does this mod do?[/b]
This mod enables your forum to be accessed by the Tapatalk app. The Tapatalk app can be downloaded from Apple iTune Store or from Google Play.

[b]What next do I have to do?[/b]
After installing this mod, head straight to http://tapatalk.com/activate_tapatalk.php and register there. After registering you can enlist your forum into the Tapatalk network.

[center][color=red][size=18pt]Please manually change permission of all files under mobiquo/ folder (including the folder itself) to chmod 755 otherwise it won't work!! And please uninstall the old tapatalk plugin completely before you install the new plugin!![/size][/color][/center]
[center][color=red][size=12pt]Please check on Forum_Root/mobiquo/config/config.txt to make sure that the config content is displayed well.(Forum_Root is the forum url you filled in forum owner area: http://tapatalk.com/landing.php)[/size][/color][/center]

[b]License[/b]
Tapatalk API for SMF 2 is free and open source software released under the BSD License. (http://www.simplemachines.org/about/smf/license.php)
This software includes a modified version of the SMF 2 open source library available at http://download.simplemachines.org/. These modifications were made by Tapatalk as of May 30, 2014.

For more information please visit http://tapatalk.com

Thank you! :)